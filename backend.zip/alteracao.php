<?php

switch ($method) {
case 'PUT': // Alteração de usuário
        if (!isset($input['id']) || !isset($input['nome']) || !isset($input['email'])) {
            http_response_code(response_code: 400);
            echo json_encode(value: ['error' => 'ID, nome e email são obrigatórios']);
            exit;
        }

        $id = $input['id'];
        $nome = $input['nome'];
        $email = $input['email'];

        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare(query: "UPDATE usuarios SET nome = :nome, email = :email WHERE id = :id");
            $stmt->execute(params: ['nome' => $nome, 'email' => $email, 'id' => $id]);

            if ($stmt->rowCount() > 0) {
                echo json_encode(value: ['success' => 'Usuário atualizado com sucesso']);
            } else {
                http_response_code(response_code: 404);
                echo json_encode(value: ['error' => 'Usuário não encontrado']);
            }
        } catch (PDOException $e) {
            http_response_code(response_code: 500);
            echo json_encode(value: ['error' => $e->getMessage()]);
        }
        break;
    }
        ?>