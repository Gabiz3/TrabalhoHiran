<?php
require_once 'db_connect.php'; // Altere para o caminho do arquivo da função

$conexao = getConnection();

if ($conexao) {
    echo "Conexão bem-sucedida!";
} else {
    echo "Falha na conexão!";
}

?>