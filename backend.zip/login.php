<?php
require_once 'db_connect.php';
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

switch ($method) {
    case 'POST':
        if (isset($input['action']) && $input['action'] === 'login') {
            if (!isset($input['email']) || !isset($input['senha'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Email e senha são obrigatórios']);
                exit;
            }

            $email = $input['email'];
            $senha = $input['senha'];

            try {
                $pdo = getConnection();
                $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = :email");
                $stmt->execute(['email' => $email]);
                $user = $stmt->fetch();

                if ($user && password_verify($senha, $user['senha'])) {
                    $token = base64_encode($user['id'] . ':' . uniqid());
                    echo json_encode(['success' => 'Login realizado com sucesso', 'token' => $token]);
                } else {
                    http_response_code(401);
                    echo json_encode(['error' => 'Email ou senha inválidos']);
                }
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        } else {
            if (!isset($input['nome']) || !isset($input['email']) || !isset($input['senha'])) {
                http_response_code(400);
                echo json_encode(['error' => 'Nome, email e senha são obrigatórios']);
                exit;
            }

            $nome = $input['nome'];
            $email = $input['email'];
            $senha = $input['senha'];

            try {
                $pdo = getConnection();
                $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = :email");
                $stmt->execute(['email' => $email]);

                if ($stmt->fetch()) {
                    http_response_code(409);
                    echo json_encode(['error' => 'Email já cadastrado']);
                    exit;
                }

                $senhaHash = password_hash($senha, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)");
                $stmt->execute(['nome' => $nome, 'email' => $email, 'senha' => $senhaHash]);

                echo json_encode(['success' => 'Usuário cadastrado com sucesso']);
            } catch (PDOException $e) {
                http_response_code(500);
                echo json_encode(['error' => $e->getMessage()]);
            }
        }
        break;

    case 'PUT':
        if (!isset($input['id']) || !isset($input['nome']) || !isset($input['email'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ID, nome e email são obrigatórios']);
            exit;
        }

        $id = $input['id'];
        $nome = $input['nome'];
        $email = $input['email'];

        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("UPDATE usuarios SET nome = :nome, email = :email WHERE id = :id");
            $stmt->execute(['nome' => $nome, 'email' => $email, 'id' => $id]);

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => 'Usuário atualizado com sucesso']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Usuário não encontrado']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'DELETE':
        if (!isset($input['id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ID é obrigatório']);
            exit;
        }

        $id = $input['id'];

        try {
            $pdo = getConnection();
            $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = :id");
            $stmt->execute(['id' => $id]);

            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => 'Usuário excluído com sucesso']);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'Usuário não encontrado']);
            }
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método não permitido']);
        break;
}
?>