<?php

// Função de conexão com o banco de dados
function getConnection(): PDO {
    $host = 'painel_usuario.mysql.dbaas.com.br';
    $db = 'painel_usuario';
    $user = 'painel_usuario';
    $pass = 'B3terr4b@';
    $dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

    try {
        return new PDO(dsn: $dsn, username: $user, password: $pass, options: [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        http_response_code(response_code: 500);
        echo json_encode(value: ['error' => $e->getMessage()]);
        exit;
    }
}

?>