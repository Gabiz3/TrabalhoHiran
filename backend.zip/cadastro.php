<?php

require_once 'db_connect.php';

switch ($method) {
    case 'POST': // Cadastro de usuário
    if (!isset($input['nome']) || !isset($input['email']) || !isset($input['senha'])) {
        http_response_code(response_code: 400);
        echo json_encode(value: ['error' => 'Nome, email e senha são obrigatórios']);
        exit;
    }

    $nome = $input['nome'];
    $email = $input['email'];
    $senha = $input['senha'];

    try {
        $pdo = getConnection();

        // Verificar se o email já está cadastrado
        $stmt = $pdo->prepare(query: "SELECT id FROM usuarios WHERE email = :email");
        $stmt->execute(params: ['email' => $email]);

        if ($stmt->fetch()) {
            http_response_code(response_code: 409);
            echo json_encode(value: ['error' => 'Email já cadastrado']);
            exit;
        }

        // Gerar o hash da senha
        $senhaHash = password_hash(password: $senha, algo: PASSWORD_BCRYPT);

        // Inserir o usuário no banco
        $stmt = $pdo->prepare(query: "INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)");
        $stmt->execute(params: [
            'nome' => $nome,
            'email' => $email,
            'senha' => $senhaHash
        ]);

        echo json_encode(value: ['success' => 'Usuário cadastrado com sucesso']);
    } catch (PDOException $e) {
        http_response_code(response_code: 500);
        echo json_encode(value: ['error' => $e->getMessage()]);
    }
    break;
    ?>